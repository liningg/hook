﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Text;

namespace EcgNetPlug
{
    /// <summary>
    ///DbSQLHelper 的摘要说明
    /// </summary>
    public class DbSQLHelper
    {
        //数据库连接字符串(web.config来配置).    
        public  string connectionString = "";
        //public static string connectionString = DbConString.ConnectionString;
        public DbSQLHelper(string conn)
        {
            //
            //TODO: 在此处添加构造函数逻辑
            //
            connectionString = conn;
        }

        #region 执行SQL语句方法

        /// <summary>
        /// 执行SQL语句，返回影响的记录数
        /// </summary>
        /// <param name="SQLString">SQL语句</param>
        /// <returns>影响的记录数</returns>
        public  int ExecuteSql(string SQLString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQLString, connection))
                {
                    try
                    {
                        connection.Open();
                        int rows = cmd.ExecuteNonQuery();
                        return rows;
                    }
                    catch (System.Data.SqlClient.SqlException e)
                    {
                        connection.Close();
                        throw e;
                    }
                }
            }
        }
        /// <summary>
        /// 执行SQL语句，返回影响的记录数
        /// </summary>
        /// <param name="SQLString">SQL语句</param>
        /// <returns>影响的记录数</returns>
        public  int ExecuteSql(string SQLString, params SqlParameter[] cmdParms)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                        int rows = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        return rows;
                    }
                    catch (System.Data.SqlClient.SqlException e)
                    {
                        throw e;
                    }
                }
            }
        }



        /// <summary>
        /// 执行查询语句，返回DataSet
        /// </summary>
        /// <param name="SQLString">查询语句</param>
        /// <returns>DataSet</returns>
        public  DataSet DataSetQuery(string SQLString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                DataSet ds = new DataSet();
                try
                {
                    connection.Open();
                    SqlDataAdapter command = new SqlDataAdapter(SQLString, connection);
                    command.Fill(ds, "ds");
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                return ds;
            }
        }
        /// <summary>
        /// 执行查询语句，返回DataSet
        /// </summary>
        /// <param name="SQLString">查询语句</param>
        /// <returns>DataSet</returns>
        public  DataSet DataSetQuery(string SQLString, params SqlParameter[] cmdParms)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand();
                PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataSet ds = new DataSet();
                    try
                    {
                        da.Fill(ds, "ds");
                        cmd.Parameters.Clear();
                    }
                    catch (System.Data.SqlClient.SqlException ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    return ds;
                }
            }
        }
        /// <summary>
        /// 返回数据表数据(无参数)
        /// </summary>
        /// <param name="SQLString"></param>
        /// <returns></returns>
        public  DataTable DataTableInfo(string SQLString)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                DataTable dt = new DataTable();
                try
                {
                    connection.Open();
                    SqlDataAdapter command = new SqlDataAdapter(SQLString, connection);
                    command.Fill(dt);
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                return dt;
            }

        }
        /// <summary>
        /// 返回数据表数据(有参数)
        /// </summary>
        /// <param name="SQLString">查询语句</param>
        /// <param name="cmdParms">查询条件参数</param>
        /// <returns></returns>
        public  DataTable DataTableInfo(string SQLString, params SqlParameter[] cmdParms)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand();
                PrepareCommand(cmd, connection, null, SQLString, cmdParms);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    try
                    {
                        da.Fill(dt);
                        cmd.Parameters.Clear();
                    }
                    catch (System.Data.SqlClient.SqlException ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    return dt;
                }
            }

        }
        /// <summary>
        /// 执行事务
        /// </summary>
        /// <param name="sqlItems">要执行事务操作的一组SQL语句</param>
        /// <param name="tranName">事务名称</param>
        /// <returns>事务操作结果</returns>
        public bool ExecuteTrasaction(List<string> sqlItems, string tranName)
        {
            bool result = true;
            SqlTransaction tran = null;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                try
                {
                    tran = conn.BeginTransaction(tranName);

                    foreach (var sqlStr in sqlItems)
                    {
                        var cmd = new SqlCommand(sqlStr, conn, tran);
                        cmd.ExecuteNonQuery();
                    }

                    tran.Commit();
                    result = true;
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    result = false;
                }
                return result;
            }
        }

        /// <summary>
        /// 执行事务
        /// </summary>
        /// <param name="sqlItems">要执行事务操作的一组SQL语句</param>
        /// <param name="tranName">事务名称</param>
        /// <returns>事务操作结果</returns>
        public bool ExecuteTrasaction(List<SqlEntity> sqlItems, string tranName)
        {
            bool result = true;
            SqlTransaction tran = null;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                StringBuilder builder = new StringBuilder();
                try
                {
                    tran = conn.BeginTransaction(tranName);
                    foreach (var kvp in sqlItems)
                    {
                        var cmd = new SqlCommand(kvp.Sql, conn, tran);
                        cmd.Parameters.AddRange(kvp.Parameter);
                        cmd.ExecuteNonQuery();
                    }
                    tran.Commit();
                    result = true;
                }
                catch (Exception exp)
                {
                    tran.Rollback();
                    result = false;
                    throw exp;
                }
                return result;
            }
        }
        private  void PrepareCommand(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
                conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
                cmd.Transaction = trans;
            cmd.CommandType = CommandType.Text;//cmdType;
            if (cmdParms != null)
            {


                foreach (SqlParameter parameter in cmdParms)
                {
                    if ((parameter.Direction == ParameterDirection.InputOutput || parameter.Direction == ParameterDirection.Input) &&
                        (parameter.Value == null))
                    {
                        parameter.Value = DBNull.Value;
                    }
                    cmd.Parameters.Add(parameter);
                }
            }
        }
        #endregion
    }
    /// <summary>
    /// 带餐T-Sql语句实体类
    /// </summary>
    public class SqlEntity
    {
        /// <summary>
        /// sql语句
        /// </summary>
        public string Sql { get; set; }

        /// <summary>
        /// 参数
        /// </summary>
        public SqlParameter[] Parameter { get; set; }
    }
}