﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace EcgNetPlug.WorkJob.Statistics
{
    public class StatisticWorkDb
    {
        private string connectionStr = "";
        public StatisticWorkDb(string conn)
        {
            connectionStr = conn;
        }
        /// <summary>
        /// 获取所有该类型的医疗机构
        /// </summary>
        /// <param name="tag">MedicalOrgType</param>
        /// <returns></returns>
        public DataTable GetAllMedicalId(string tag)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from MedicalOrg where MedicalOrgType='{0}'";
            strSql = string.Format(strSql, tag);
            return helper.DataTableInfo(strSql);
        }

        /// <summary>
        /// 获取服务中心（医院）的数量
        /// </summary>
        /// <returns></returns>
        public DataTable GetHospitalFromArea(string areaId,int valid)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from MedicalOrg where ParentID='{0}'and IsValid = {1}";
            strSql = string.Format(strSql, areaId,valid);
            return helper.DataTableInfo(strSql);
        }
        public DataTable GetHospitalFromArea(string areaId)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from MedicalOrg where ParentID='{0}'";
            strSql = string.Format(strSql, areaId);
            return helper.DataTableInfo(strSql);
        }
        /// <summary>
        /// 获取医院下面的所有科室
        /// </summary>
        /// <param name="hospitalId"></param>
        /// <returns></returns>
        public DataTable GetDepartFromHospital(string hospitalId)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from Department where MedicalOrgId='{0}'";
            strSql = string.Format(strSql, hospitalId);
            return helper.DataTableInfo(strSql);
        }
        public DataTable GetDepartFromHospital(string hospitalId, int valid)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from Department where MedicalOrgId='{0}'and IsValid = {1} ";
            strSql = string.Format(strSql, hospitalId, valid);
            return helper.DataTableInfo(strSql);
        }
        /// <summary>
        /// 更新 统计表
        /// </summary>
        /// <param name="medicalId"></param>
        /// <param name="serviceCenter"></param>
        /// <param name="remoteServiceCenter"></param>
        /// <param name="serviceStation"></param>
        /// <param name="remoteServiceStation"></param>
        /// <returns></returns>
        public int UpdateStatisticBusinessTable(string medicalId, int serviceCenter, int remoteServiceCenter, int serviceStation, int remoteServiceStation)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from Statistics_Business where MedicalOrgId='{0}'";
            strSql = string.Format(strSql, medicalId);
            DataTable table =  helper.DataTableInfo(strSql);
            if(table.Rows.Count > 0)
            {
                strSql = @"UPDATE  [Statistics_Business] SET [ServiceCenter] = '{0}',[RemoteServiceCenter] = '{1}',[ServiceStation] = '{2}',[RemoteServiceStation] = '{3}' WHERE [MedicalOrgId] = '{4}'";
                strSql = string.Format(strSql, serviceCenter, remoteServiceCenter, serviceStation, remoteServiceStation, medicalId);
                return helper.ExecuteSql(strSql);
            }
            else
            {
                strSql = @"INSERT INTO [Statistics_Business] ([MedicalOrgId], [ServiceCenter], [RemoteServiceCenter], [ServiceStation],[RemoteServiceStation]) VALUES 
                                      ('{0}', '{1}', '{2}', '{3}','{4}')";
                strSql = string.Format(strSql, medicalId, serviceCenter, remoteServiceCenter, serviceStation, remoteServiceStation);
                return helper.ExecuteSql(strSql);
            }
        }
        /// <summary>
        /// 获取所有的额科室的所有的设备
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllDepartDevice()
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select DEP.DepartId,DIC.DicKey AS DevType,DEP.MedicalOrgId, dev.IsValid AS DevIsValid,COUNT(*) AS DevCount from Devices DEV
                            left join DeviceDepart DD ON DD.DeviceId=DEV.DeviceId
                            LEFT JOIN Department DEP ON DEP.DepartId=DD.DeptId
                            LEFT JOIN Dictionary DIC ON DIC.DicKey=DEV.DeviceType
                            WHERE DEV.IsValid='1'
                            GROUP BY DEP.DepartId,DIC.DicKey,DEP.MedicalOrgId, dev.IsValid,DIC.DicValue";
            strSql = string.Format(strSql);
            return helper.DataTableInfo(strSql);
        }
        public int DeleteStatisticDeviceTable()
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"delete from Statistics_Device";
            strSql = string.Format(strSql);
            return helper.ExecuteSql(strSql);
        }
        /// <summary>
        /// 更新统计设备表
        /// </summary>
        /// <param name="departId"></param>
        /// <param name="medicalId"></param>
        /// <param name="deviceType"></param>
        /// <param name="deviceCnt"></param>
        /// <returns></returns>
        public int UpdateStatisticsDeviceTable(string departId,string medicalId,string deviceType,int deviceCnt)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from Statistics_Device where DepartId='{0}'";
            strSql = string.Format(strSql, departId);
            DataTable table = helper.DataTableInfo(strSql);
            if(table.Rows.Count > 0)
            {
                deviceCnt = deviceCnt + Convert.ToInt32(table.Rows[0]["DeviceCount"].ToString());
                strSql = @"UPDATE  [Statistics_Device] SET [MedicalOrgId] = '{0}',[DeviceType] = '{1}',[DeviceCount] = '{2}'WHERE [DepartId] = '{3}'";
                strSql = string.Format(strSql, medicalId, deviceType, deviceCnt, departId);
                return helper.ExecuteSql(strSql);
            }
            else
            {
                strSql = @"INSERT INTO [Statistics_Device] ([DepartId],[MedicalOrgId], [DeviceType], [DeviceCount]) VALUES 
                                      ('{0}', '{1}', '{2}', '{3}')";
                strSql = string.Format(strSql, departId, medicalId, deviceType, deviceCnt);
                return helper.ExecuteSql(strSql);
            }
        }
        /// <summary>
        /// 获取所有的科室的诊端信息
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllDiagnosisNum()
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"SELECT AF.AppliDept,AF.MedicalOrgId,AF.ExamItemId,convert(char(10), AF.ComeDate,120) as Date, COUNT(*) as DiagnosisCount FROM ApplicationForm AF	
                            WHERE AF.State IN('3','7') AND AF.IsValid='1'
                            GROUP BY AF.AppliDept,AF.MedicalOrgId,AF.ExamItemId,convert(char(10), AF.ComeDate,120)";
            strSql = string.Format(strSql);
            return helper.DataTableInfo(strSql);
        }
        public DataTable GetAbNormalDiagnosNum(string departId,string examItemId,string comeBeginDate,string comeEndDate )
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"SELECT COUNT(*)as Count FROM ApplicationForm AF	
                            LEFT JOIN ExamRecord ER ON ER.AppliId = AF.AppliId AND ER.IsValid='1'
                            RIGHT JOIN Diagnosis DIA ON DIA.ExamRecordId=ER.ExamRecordId AND DIA.IsValid='1' AND DIA.DiagnosResult NOT LIKE '%正常%'
                            WHERE AF.State IN('3','7') AND AF.IsValid='1' AND AF.AppliDept='{0}' AND AF.ExamItemId='{1}'
                             AND AF.ComeDate>'{2}'AND AF.ComeDate<'{3}' ";
            strSql = string.Format(strSql,departId, examItemId, comeBeginDate,comeEndDate);
            return helper.DataTableInfo(strSql);
        }
        /// <summary>
        /// 更新诊端表，删除掉 异常率字段
        /// </summary>
        /// <param name="medicalId"></param>
        /// <param name="departId"></param>
        /// <param name="examItemId"></param>
        /// <param name="diagnosCount"></param>
        /// <param name="year"></param>
        /// <param name="month"></param>
        /// <param name="day"></param>
        /// <param name="positive"></param>
        /// <param name="positiveRate"></param>
        /// <returns></returns>
        public int UpdateStatisticDiagnosTable(string medicalId,string departId,string examItemId,int diagnosCount,string year,string month,string day,int positive,string positiveRate)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from Statistics_Diagnosis where DepartId='{0}'and ExamItemId = '{1}'and Year = '{2}'and Month = '{3}'and Day = '{4}'";
            strSql = string.Format(strSql, departId,examItemId,year,month,day);
            DataTable table = helper.DataTableInfo(strSql);
            if (table.Rows.Count > 0)
            {
                strSql = @"UPDATE  [Statistics_Diagnosis] SET [DiagnosisCount] = '{0}',[Positive] = '{1}' WHERE [DepartId]='{2}'and [ExamItemId] = '{3}'and [Year] = '{4}'and [Month] = '{5}'and [Day] = '{6}'";
                strSql = string.Format(strSql, diagnosCount, positive, departId,examItemId,year,month,day);
                return helper.ExecuteSql(strSql);
            }
            else
            {
                strSql = @"INSERT INTO [Statistics_Diagnosis] ([MedicalOrgId], [ExamItemId], [DiagnosisCount],[Year],[Month],[Day],[Positive],[DepartId]) VALUES 
                                      ('{0}', '{1}', '{2}', '{3}','{4}','{5}','{6}','{7}')";
                strSql = string.Format(strSql, medicalId, examItemId, diagnosCount, year,month,day,positive, departId);
                return helper.ExecuteSql(strSql);
            }
        }
    }
}
