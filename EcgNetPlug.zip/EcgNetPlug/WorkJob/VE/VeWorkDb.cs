﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace EcgNetPlug.WorkJob.VE
{
    public class VeWorkDb
    {
        private string connectionStr = "";
        public VeWorkDb(string conn)
        {
            connectionStr = conn;
        }
        public int InsertMeasureData(string measureId,string path,string type,bool isvalid)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"INSERT INTO [MeasureData] ([MeasureId], [FilePath], [Type], [Isvalid]) VALUES 
                                      ('{0}', '{1}', '{2}', '{3}')";
            strSql = string.Format(strSql, measureId, path, type, isvalid);
            return helper.ExecuteSql(strSql);
        }
        public DataTable GetMeasureRecord(string hospitalId)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"select * from MeasureData as mea where mea.MeasureId in 
                            (
	                            select MeasureId from ExamRecord as exa where exa.AppliId in 
	                            (
		                            select AppliId from ApplicationForm as app where app.MedicalOrgId in ({0})
	                            )
                            )";
            strSql = string.Format(strSql, hospitalId);
            return helper.DataTableInfo(strSql);

        }
        public DataTable GetDiagnosRecord(string hospitalId)
        {
            DbSQLHelper helper = new DbSQLHelper(connectionStr);
            string strSql = @"
                            select * from MeasureData as mea left join Diagnosis as dia on mea.MeasureId = dia.MeasureId where mea.MeasureId in 
                            (
	                            select dia.MeasureId from Diagnosis as dia where dia.ExamRecordId in 
	                            (
		                            select exa.ExamRecordId from ExamRecord as exa where exa.AppliId in 
		                            (
			                            select app.AppliId from ApplicationForm as app where app.MedicalOrgId in ({0})
		                            )
	                            )
                            )";
            strSql = string.Format(strSql, hospitalId);
            return helper.DataTableInfo(strSql);
        }
    }
}
