﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EcgNetPlug
{
    public class WorkList
    {

        //任务字典
        private Dictionary<string, WorkJob> dicBaseJob = null;

        public WorkList()
        {
            dicBaseJob = new Dictionary<string, WorkJob>();
        }
        public Dictionary<string, WorkJob> GetDictionayWork()
        {
            return dicBaseJob;
        }
        public void SetWork(string name, WorkJob job)
        {
            if(FindWork(name))
            {
                dicBaseJob[name] = job;
            }
        }
        public void AddWork(string name, WorkJob job)
        {
            if(!FindWork(name))
            {
                dicBaseJob.Add(name, job);
            }
        }
        public WorkJob GetWork(string name)
        {
            if(FindWork(name))
            {
                return dicBaseJob[name];
            }
            return null;
        }
        public bool FindWork(string name)
        {
            bool ret = false;
            if(dicBaseJob != null && dicBaseJob.ContainsKey(name))
            {
                ret = true;
            }
            return ret;
        }
        public void Start()
        {
            foreach(var item in dicBaseJob)
            {
                Start(item.Key);
            }
        }
        public bool Start(string name)
        {
            bool ret = false;
            WorkJob job = dicBaseJob[name];
            if(job.job != null)
            {
                if(job.enable)
                {
                    ret = job.job.Start();
                }
                
            }
            return ret;
        }
        public void Stop()
        {
            foreach (var item in dicBaseJob)
            {
                if(item.Value.enable)
                {
                    Stop(item.Key);
                }
                
            }
        }
        public bool Stop(string name)
        {
            bool ret = false;
            WorkJob job = dicBaseJob[name];
            if (job.job != null)
            {
                ret = job.job.Stop();
            }
            return ret;
        }
        public class WorkJob
        {
            public BaseJob job = null;
            public bool enable = false;
            public int state = 0;
            public int allcnt = 0;
            public int errcnt = 0;
            public int round = 0;
        }
    }
   
}
