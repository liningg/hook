﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace EcgNetPlug
{
    public class XmlHelperEx
    {
        private XmlDocument myXmlDoc = new XmlDocument();
        public bool LoadXmlFile(string file)
        {
            bool ret = false;
            try
            {
                myXmlDoc.Load(file);
                ret = true;
            }
            catch
            {
                ret = false;
            }

            return ret;
        }
        public bool LoadXmlString(string str)
        {
            bool ret = false;
            try
            {
                myXmlDoc.LoadXml(str);
                ret = true;
            }
            catch
            {
                ret = false;
            }
            return ret;
        }
        public bool SaveXml(string file)
        {
            bool ret = false;
            try
            {
                myXmlDoc.Save(file);
                ret = true;
            }
            catch
            {
                ret = false;
            }

            return ret;
        }
        public string GetValue(string path)
        {
            string strValue = string.Empty;
            try
            {
                XmlNode node = myXmlDoc.SelectSingleNode(path);
                strValue = node.InnerText;
            }
            catch
            {
                strValue = string.Empty;
            }

            return strValue;
        }
        public bool SetValue(string path, string value)
        {
            bool ret = false;
            try
            {
                XmlNode node = myXmlDoc.SelectSingleNode(path);
                node.InnerText = value;
                ret = true;
            }
            catch
            {
                ret = false;
            }
            return ret;
        }
    }
}
