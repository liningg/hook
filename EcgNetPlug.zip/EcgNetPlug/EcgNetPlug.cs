﻿
using EcgNetPlug.WorkJob.FetalDataEnginer;
using EcgNetPlug.WorkJob.Statistics;
using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EcgNetPlug
{
    public partial class EcgNetPlug : Form
    {
        private WorkList workList = null;
        private ILog log = null;
        private bool wndEnable = true;
        private int refreshTime = 5000;

        public EcgNetPlug()
        {
            InitializeComponent();
            workList = new WorkList();
            log = LogManager.GetLogger("EcgNetPlug");
            
        }

        private void EcgNetPlug_Load(object sender, EventArgs e)
        {
            log.Info("EcgNetPlug_Load");

            //初始化任务列表
            InitWorkJob();
            //开启任务
            workList.Start();

            InitWindow();
           

        }
        private void InitWindow()
        {
            //启动定时器
            refreshTime = Convert.ToInt32(ConfigurationManager.AppSettings["Refresh"]);
            timerUpdate.Interval = refreshTime;
            timerUpdate.Start();

            //更新表格
            DataGridViewRowCollection rows = dataGridViewWork.Rows;
            rows.Clear();
            Image img = null;
            foreach (var it in workList.GetDictionayWork())
            {
                if (!it.Value.enable)
                {
                    img = Image.FromFile("image/disable.png");
                }
                else
                {
                    if (it.Value.state > 0)
                    {
                        img = Image.FromFile("image/running.png");
                    }
                    else
                    {
                        img = Image.FromFile("image/stop.png");
                    }

                }
                rows.Add(it.Value.job.GetWorkName(), img, it.Value.allcnt, it.Value.errcnt);
            }

        }
        /// <summary>
        /// 初始化所有的工作任务
        /// </summary>
        private void InitWorkJob()
        {
            log.Info("InitWorkJob");
            int veEnable = Convert.ToInt32(ConfigurationManager.AppSettings["VE"]);
            int StatisticEnable = Convert.ToInt32(ConfigurationManager.AppSettings["Statistic"]);
            int FetalDataEnginerEnable = Convert.ToInt32(ConfigurationManager.AppSettings["FetalDataEnginer"]);

            //添加一个ve的工作任务
            AddVeWorkJob(veEnable);
            
            //添加一个统计的工作任务
            AddStatisticWorkJob(StatisticEnable);
            
            //添加一个胎监的数据引擎任务
            AddFetalDataEnginerWorkJob(FetalDataEnginerEnable);

        }
        private void UninitWorkJob()
        {
            log.Info("InitWorkJob");
            workList.Stop();
        }
        /// <summary>
        /// 添加一个数据引擎的任务
        /// </summary>
        /// <returns></returns>
        private void AddFetalDataEnginerWorkJob(int enable)
        {
            log.Info("AddFetalDataEnginerWorkJob");
            FetalDataEnginerWorkJob job = new FetalDataEnginerWorkJob("FetalDataEnginer");
            job.evetWorkState += ReportState;
            job.SetConfigDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "config/FetalDataEnginer/");

            WorkList.WorkJob work = new WorkList.WorkJob();
            work.job = job;
            work.enable = enable == 1 ? true : false;
            workList.AddWork(work.job.GetWorkName(), work);
        }
        /// <summary>
        /// 添加一个统计的任务
        /// </summary>
        /// <returns></returns>
        private void AddStatisticWorkJob(int enable)
        {
            log.Info("AddStatisticWorkJob");
            StatisticWorkJob job = new StatisticWorkJob("Statistic");
            job.evetWorkState += ReportState;
            job.SetConfigDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "config/Statistic/");

            WorkList.WorkJob work = new WorkList.WorkJob();
            work.job = job;
            work.enable = enable == 1 ? true : false;
            workList.AddWork(work.job.GetWorkName(), work);
        }

        /// <summary>
        /// 添加一个ve的工作任务
        /// </summary>
        /// <returns></returns>
        private void AddVeWorkJob(int enable)
        {
            log.Info("AddVeWorkJob");
            VeWorkJob job = new VeWorkJob("VE");
            job.evetWorkState += ReportState;
            job.SetEcgViewOcx(axECGViewerOCX1);
            job.SetConfigDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "config/ve/");

            WorkList.WorkJob work = new WorkList.WorkJob();
            work.job = job;
            work.enable = enable == 1 ? true : false;
            workList.AddWork(work.job.GetWorkName(), work);
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EcgNetPlug_FormClosed(object sender, FormClosedEventArgs e)
        {
            UninitWorkJob();
        }

        private void EcgNetPlug_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                //this.Visible = false;
                //this.notifyIcon1.Visible = true;
            }
        }

        private void EcgNetPlug_Shown(object sender, EventArgs e)
        {
            //this.Hide();
            //Opacity = 0;
        }
        private void ReportState(string name,int code,int cnt)
        {
            WorkList.WorkJob job = workList.GetWork(name);
            if(code == 1)
            {
                job.state += cnt;
                job.allcnt += cnt;
                //一天有这么多秒
                if(job.allcnt > 86400)
                {
                    job.round++;
                    job.allcnt = 0;
                }
            }
            else if(code == 2)
            {
                job.errcnt += cnt;
            }
            
            workList.SetWork(name, job);
            DataGridViewRowCollection rows = dataGridViewWork.Rows;
            Image img = null;
            if (!job.enable)
            {
                img = Image.FromFile("image/disable.png");
            }
            else
            {
                if (job.state > 0)
                {
                    img = Image.FromFile("image/running.png");
                }
                else
                {
                    img = Image.FromFile("image/stop.png");
                }

            }
            int index = GetDataGridViewRowIndex(name);
            if(index >= 0)
            {
                rows.SharedRow(index).SetValues(name, img, job.allcnt, job.errcnt,job.round);
            }
           
            Console.WriteLine(name + ":" + code + "," + cnt);
        }
        private int GetDataGridViewRowIndex(string name)
        {
            DataGridViewRowCollection rows = dataGridViewWork.Rows;
            int index = -1;
            foreach (DataGridViewRow item in rows)
            {
                object obj = item.Cells[0].Value;
                if(obj != null)
                {
                    if (obj.ToString() == name)
                    {
                        index = item.Index;
                        break;
                    }
                }
            }
            return index;
        }

        private void timerUpdate_Tick(object sender, EventArgs e)
        {
            DataGridViewRowCollection rows = dataGridViewWork.Rows;
            Image img = null;
            foreach (var it in workList.GetDictionayWork())
            {
                if (!it.Value.enable)
                {
                    img = Image.FromFile("image/disable.png");
                }
                else
                {
                    if (it.Value.state > 0)
                    {
                        img = Image.FromFile("image/running.png");
                    }
                    else
                    {
                        img = Image.FromFile("image/stop.png");
                    }

                }
                int index = GetDataGridViewRowIndex(it.Key);
                if (index >= 0)
                {
                    rows.SharedRow(index).SetValues(it.Key, img, it.Value.allcnt, it.Value.errcnt, it.Value.round);
                }
            }
                
            foreach (var it in workList.GetDictionayWork())
            {
                it.Value.state = 0;
            }
            
        }

        private void buttonTaskStart_Click(object sender, EventArgs e)
        {
            string str = dataGridViewWork.CurrentRow.Cells[0].Value.ToString();
            if(workList.Start(str))
            {
                MessageBox.Show("任务开启成功");
            }
            else
            {
                MessageBox.Show("任务开启失败");
            }
        }

        private void buttonTaskStop_Click(object sender, EventArgs e)
        {
            string str = dataGridViewWork.CurrentRow.Cells[0].Value.ToString();
            if (workList.Stop(str))
            {
                MessageBox.Show("任务关闭成功");
            }
            else
            {
                MessageBox.Show("任务关闭失败");
            }
        }

        private void buttonOpenConfig_Click(object sender, EventArgs e)
        {
            string str = dataGridViewWork.CurrentRow.Cells[0].Value.ToString();
            string path = workList.GetWork(str).job.configDirectory;
            System.Diagnostics.Process.Start(path);
        }

    }
}
