﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace EcgNetPlug
{
    public class BaseJob
    {
        public string jsonName = "";
        public Thread td = null;
        public bool running = false;
        private int sleepTimeState = 1000;
        public int sleepTimeWork = 1000;
        private int sleepTemp = 0;
        public string workName = string.Empty;
        public string configDirectory = string.Empty;
        public delegate void DelagateWorkState(string name,int code,int cnt);
        public event DelagateWorkState evetWorkState = null;
        public virtual void Init(string name)
        {
            workName = name;
            configDirectory = System.AppDomain.CurrentDomain.BaseDirectory;
        }
        public void SetConfigDirectory(string dir)
        {
            configDirectory = dir;
        }
        public string GetConfigDirectory()
        {
            return configDirectory;
        }
        public virtual bool Start(int sleep = 1000)
        {
            bool ret = false;
            if (!running)
            {
                sleepTimeWork = sleep;
                try
                {
                    running = true;
                    td = new System.Threading.Thread(Run);
                    td.Start();
                    ret = true;
                }
                catch
                {
                    ret = false;
                }

            }
            return ret;
        }
        public virtual bool Stop()
        {
            bool ret = false;
            if(running)
            {
                try
                {
                    if (td != null)
                    {
                        running = false;
                        td.Abort();
                        ret = true;
                    }
                }
                catch
                {
                    ret = false;
                }
            }
            return ret;
        }
        public string GetWorkName()
        {
            return workName;
        }
        private int WaitingWorkTime()
        {
            int sleeptime = 0;
            if(sleepTimeWork < sleepTimeState)
            {
                sleeptime = sleepTimeWork;
            }
            else
            {
                if(sleepTemp + sleepTimeState >= sleepTimeWork)
                {
                    sleeptime = sleepTemp + sleepTimeState - sleepTimeWork;
                    sleepTemp = 0;
                }
                else
                {
                    sleeptime = sleepTimeState;
                    sleepTemp += sleepTimeState;
                }
            }
            return sleeptime;
        }
        public void ReportWorkState(int code,int cnt)
        {
            if(evetWorkState != null)
            {
                evetWorkState(workName,code,cnt);
            }
        }
        public virtual void Run()
        {
            int sleeptime = WaitingWorkTime();
            ReportWorkState(1,1);
            Thread.Sleep(sleeptime);
            
        }

    }
}
