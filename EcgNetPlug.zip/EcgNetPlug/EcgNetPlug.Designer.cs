﻿namespace EcgNetPlug
{
    partial class EcgNetPlug
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EcgNetPlug));
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridViewWork = new System.Windows.Forms.DataGridView();
            this.buttonOpenConfig = new System.Windows.Forms.Button();
            this.buttonTaskStop = new System.Windows.Forms.Button();
            this.buttonTaskStart = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxReboot = new System.Windows.Forms.CheckBox();
            this.buttonSet = new System.Windows.Forms.Button();
            this.timerUpdate = new System.Windows.Forms.Timer(this.components);
            this.TaskName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TaskState = new System.Windows.Forms.DataGridViewImageColumn();
            this.TaskAllCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TaskErrCnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TaskRound = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.axECGViewerOCX1 = new AxECGViewerOCXLib.AxECGViewerOCX();
            this.contextMenuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWork)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axECGViewerOCX1)).BeginInit();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(101, 26);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(636, 302);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridViewWork);
            this.tabPage1.Controls.Add(this.buttonOpenConfig);
            this.tabPage1.Controls.Add(this.buttonTaskStart);
            this.tabPage1.Controls.Add(this.buttonTaskStop);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(628, 276);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "基本设置";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridViewWork
            // 
            this.dataGridViewWork.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWork.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TaskName,
            this.TaskState,
            this.TaskAllCnt,
            this.TaskErrCnt,
            this.TaskRound});
            this.dataGridViewWork.Location = new System.Drawing.Point(6, 8);
            this.dataGridViewWork.MultiSelect = false;
            this.dataGridViewWork.Name = "dataGridViewWork";
            this.dataGridViewWork.ReadOnly = true;
            this.dataGridViewWork.RowTemplate.Height = 23;
            this.dataGridViewWork.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewWork.Size = new System.Drawing.Size(533, 262);
            this.dataGridViewWork.TabIndex = 5;
            // 
            // buttonOpenConfig
            // 
            this.buttonOpenConfig.Location = new System.Drawing.Point(545, 65);
            this.buttonOpenConfig.Name = "buttonOpenConfig";
            this.buttonOpenConfig.Size = new System.Drawing.Size(75, 23);
            this.buttonOpenConfig.TabIndex = 3;
            this.buttonOpenConfig.Text = "打开配置";
            this.buttonOpenConfig.UseVisualStyleBackColor = true;
            this.buttonOpenConfig.Click += new System.EventHandler(this.buttonOpenConfig_Click);
            // 
            // buttonTaskStop
            // 
            this.buttonTaskStop.Location = new System.Drawing.Point(545, 36);
            this.buttonTaskStop.Name = "buttonTaskStop";
            this.buttonTaskStop.Size = new System.Drawing.Size(75, 23);
            this.buttonTaskStop.TabIndex = 2;
            this.buttonTaskStop.Text = "关闭任务";
            this.buttonTaskStop.UseVisualStyleBackColor = true;
            this.buttonTaskStop.Click += new System.EventHandler(this.buttonTaskStop_Click);
            // 
            // buttonTaskStart
            // 
            this.buttonTaskStart.Location = new System.Drawing.Point(545, 7);
            this.buttonTaskStart.Name = "buttonTaskStart";
            this.buttonTaskStart.Size = new System.Drawing.Size(75, 23);
            this.buttonTaskStart.TabIndex = 1;
            this.buttonTaskStart.Text = "开启任务";
            this.buttonTaskStart.UseVisualStyleBackColor = true;
            this.buttonTaskStart.Click += new System.EventHandler(this.buttonTaskStart_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(628, 276);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "高级设置";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxReboot);
            this.groupBox1.Controls.Add(this.buttonSet);
            this.groupBox1.Location = new System.Drawing.Point(7, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(394, 64);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "开机启动";
            // 
            // checkBoxReboot
            // 
            this.checkBoxReboot.AutoSize = true;
            this.checkBoxReboot.Location = new System.Drawing.Point(18, 24);
            this.checkBoxReboot.Name = "checkBoxReboot";
            this.checkBoxReboot.Size = new System.Drawing.Size(72, 16);
            this.checkBoxReboot.TabIndex = 1;
            this.checkBoxReboot.Text = "开机启动";
            this.checkBoxReboot.UseVisualStyleBackColor = true;
            // 
            // buttonSet
            // 
            this.buttonSet.Location = new System.Drawing.Point(105, 20);
            this.buttonSet.Name = "buttonSet";
            this.buttonSet.Size = new System.Drawing.Size(75, 23);
            this.buttonSet.TabIndex = 0;
            this.buttonSet.Text = "开机启动";
            this.buttonSet.UseVisualStyleBackColor = true;
            // 
            // timerUpdate
            // 
            this.timerUpdate.Interval = 5000;
            this.timerUpdate.Tick += new System.EventHandler(this.timerUpdate_Tick);
            // 
            // TaskName
            // 
            this.TaskName.HeaderText = "任务名称";
            this.TaskName.Name = "TaskName";
            this.TaskName.ReadOnly = true;
            // 
            // TaskState
            // 
            this.TaskState.HeaderText = "任务状态";
            this.TaskState.Name = "TaskState";
            this.TaskState.ReadOnly = true;
            this.TaskState.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.TaskState.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // TaskAllCnt
            // 
            this.TaskAllCnt.HeaderText = "任务次数";
            this.TaskAllCnt.Name = "TaskAllCnt";
            this.TaskAllCnt.ReadOnly = true;
            // 
            // TaskErrCnt
            // 
            this.TaskErrCnt.HeaderText = "错误次数";
            this.TaskErrCnt.Name = "TaskErrCnt";
            this.TaskErrCnt.ReadOnly = true;
            // 
            // TaskRound
            // 
            this.TaskRound.HeaderText = "任务周期";
            this.TaskRound.Name = "TaskRound";
            this.TaskRound.ReadOnly = true;
            // 
            // axECGViewerOCX1
            // 
            this.axECGViewerOCX1.Enabled = true;
            this.axECGViewerOCX1.Location = new System.Drawing.Point(158, 0);
            this.axECGViewerOCX1.Name = "axECGViewerOCX1";
            this.axECGViewerOCX1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axECGViewerOCX1.OcxState")));
            this.axECGViewerOCX1.Size = new System.Drawing.Size(19, 16);
            this.axECGViewerOCX1.TabIndex = 0;
            // 
            // EcgNetPlug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 316);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.axECGViewerOCX1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EcgNetPlug";
            this.ShowInTaskbar = false;
            this.Text = "心电网络插件";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.EcgNetPlug_FormClosed);
            this.Load += new System.EventHandler(this.EcgNetPlug_Load);
            this.Shown += new System.EventHandler(this.EcgNetPlug_Shown);
            this.Resize += new System.EventHandler(this.EcgNetPlug_Resize);
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWork)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axECGViewerOCX1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxECGViewerOCXLib.AxECGViewerOCX axECGViewerOCX1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button buttonOpenConfig;
        private System.Windows.Forms.Button buttonTaskStop;
        private System.Windows.Forms.Button buttonTaskStart;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBoxReboot;
        private System.Windows.Forms.Button buttonSet;
        private System.Windows.Forms.Timer timerUpdate;
        private System.Windows.Forms.DataGridView dataGridViewWork;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaskName;
        private System.Windows.Forms.DataGridViewImageColumn TaskState;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaskAllCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaskErrCnt;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaskRound;
    }
}

