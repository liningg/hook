﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace EcgNetPlug
{
    static class Program
    {
        private static Process RuningInstance()
        {
            Process currentProcess = Process.GetCurrentProcess();

            Process[] Processes = Process.GetProcessesByName(currentProcess.ProcessName);

            foreach (Process process in Processes)
            {
                if (process.Id != currentProcess.Id)
                {

                    if (Assembly.GetExecutingAssembly().Location.Replace("/", "\\") == currentProcess.MainModule.FileName)
                    {

                        return process;

                    }
                }
            }
            return null;
        }

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Process process = RuningInstance();
            if (process == null)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                EcgNetPlug plug = new EcgNetPlug();
                Application.Run(plug);
            }
            else
            {
                MessageBox.Show("应用程序已经在运行中。。。");
            }
        }
    }
}
