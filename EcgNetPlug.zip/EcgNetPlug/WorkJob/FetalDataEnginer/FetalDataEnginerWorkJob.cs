﻿using log4net;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;

namespace EcgNetPlug.WorkJob.FetalDataEnginer
{
    public class FetalDataEnginerWorkJob:BaseJob
    {
        private string dataEnginerPath = string.Empty;
        private string dataEnginerName = string.Empty;
        private int sleepTime = 1000;
        private ILog log = null;
        public FetalDataEnginerWorkJob(string name)
        {
            Init(name);
        }
        public override void Init(string name)
        {
            base.Init(name);
            log = LogManager.GetLogger("FetalDataEnginerWorkJob");
        }
        public override bool Start(int sleep = 1000)
        {
            bool ret = false;
            ret = ReadConfigFile();
            if(!ret)
            {
                log.Error("ReadConfigFile is false and return");
                return false;
            }
            return base.Start(sleepTime);
        }
        public override bool Stop()
        {
            DoThingCheckProcessRunning(false);
            return base.Stop();
        }
        public override void Run()
        {
            while(running)
            {
                //第一件事：检测数据进程是否存在，如果不存在就创建
                DoThingCheckProcessRunning(true);

                //Thread.Sleep(sleepTime);
                base.Run();
            }
            
        }
        private bool IsWaitingWork()
        {
            bool ret = false;
            return ret;
        }
        private void ReportWorkState()
        {

        }
        private void DoThingCheckProcessRunning(bool tag)
        {
            try
            {
                Process[] arrProcess = System.Diagnostics.Process.GetProcessesByName(dataEnginerName);
                if (arrProcess.ToList().Count > 0)
                {
                    if (!tag)
                    {

                        foreach (System.Diagnostics.Process process in arrProcess)
                        {
                            if (process.ProcessName == dataEnginerName)
                            {
                                try
                                {
                                    process.Kill(); //结束进程    
                                }
                                catch(Exception e)
                                {
                                    log.Error("Process.Kill:" + e.Message);
                                }
                                          
                            }
                        }
                    }
                }
                else
                {
                    if(tag)
                    {
                        try
                        {
                            //调用外部程序
                            Process MyProcess = new Process();
                            MyProcess.StartInfo.FileName = dataEnginerPath;
                            MyProcess.StartInfo.Verb = "Open";
                            MyProcess.StartInfo.CreateNoWindow = true;
                            MyProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            MyProcess.Start();
                        }
                        catch (Exception d)
                        {
                            log.Error("Process.Start:" + d.Message);
                        }
                    }
                }
            }
            catch(Exception d)
            {
                log.Error("Process.GetProcessesByName" + d.Message);
            }
           
        }

        private bool ReadConfigFile()
        {
            bool ret = false;
            XmlHelperEx xmlHelper = new XmlHelperEx();
            try
            {
                if (xmlHelper.LoadXmlFile(configDirectory + "config.xml"))
                {
                    //加载链接字符串
                    dataEnginerPath = xmlHelper.GetValue("root/dataenginerpath");
                    dataEnginerName = xmlHelper.GetValue("root/dataenginername");
                    sleepTime = Convert.ToInt32(xmlHelper.GetValue("root/sleeptime"));
                    ret = true;
                }
            }
            catch
            {
                log.Error("LoadXmlFile:" + configDirectory + "config.xml");
            }
            return ret;
        }
    }
}
