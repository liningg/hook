﻿using EcgNetPlug.WorkJob.VE;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml.Linq;

namespace EcgNetPlug
{
    public class VeWorkJob : BaseJob
    {
        private string hospitalId = "";
        private string connStr = "";
        private VeWorkDb db = null;
        private string rootDir = "";
        private AxECGViewerOCXLib.AxECGViewerOCX ocx = null;
        private string configDirectory = "";
        private int sleepTime = 2000;
        private ILog log = null;
        public VeWorkJob(string name)
        {
            Init(name);
        }
        public override void Init(string name)
        {
            base.Init(name);
            log = LogManager.GetLogger("VeWorkJob");
        }
        public void SetEcgViewOcx(AxECGViewerOCXLib.AxECGViewerOCX ocx)
        {
            log.Info("SetEcgViewOcx");
            this.ocx = ocx;
        }
        public override bool Start(int sleep = 1000)
        {
            log.Info("Start");
            bool ret = false;
            ret = ReadConfigFile();
            if(!ret)
            {
                log.Error("ReadConfigFile is false and return");
                return false;
            }
            db = new VeWorkDb(connStr);
            
            return base.Start(sleepTime);
        }
        public override void Run()
        {
            while (running)
            {
                //第一件事 ：将测量文件转换成pdf,并发送给ve
                DoThingsMeasure();

                //第二件事 ：接收到ve的诊断结论后，需要重新生成诊断pdf ,插入到我们的数据库，并且发送给ve
                DoThingsDiagnos();

                //第三件事 ： 。。。

                //Thread.Sleep(sleepTime);
                base.Run();
            }
           
        }

        private void DoThingsDiagnos()
        {
            //throw new NotImplementedException();
            try
            {
                DataTable tableMeasure = db.GetDiagnosRecord(hospitalId);
                string xmlfile = "";
                string datfile = "";
                string diaresult = "";
                string diadatetime = "";
                for (int i = 0; i < tableMeasure.Rows.Count; i++)
                {
                    DataRow rowMeasureData = tableMeasure.Rows[i];
                    diaresult = rowMeasureData["DiagnosResult"].ToString();
                    diadatetime = rowMeasureData["DiagnosDate"].ToString();
                    string measureId = rowMeasureData["MeasureId"].ToString();
                    if (rowMeasureData["Type"].ToString() == "dat")
                    {
                        datfile = rowMeasureData["FilePath"].ToString();
                    }
                    if (rowMeasureData["Type"].ToString() == "xml")
                    {
                        xmlfile = rowMeasureData["FilePath"].ToString();
                    }
                    if (rowMeasureData["Type"].ToString() == "pdf")
                    {
                        xmlfile = "";
                        datfile = "";
                    }
                    if (xmlfile != "" && datfile != "")
                    {
                        //第二部 修改xml 数据，增加诊断时间和诊断结论
                        if (ModifyDiagnosXml(xmlfile, diaresult, diadatetime))
                        {
                            //第四部 生成诊断pdf，根据xml 和 dat
                            string pdffile = GenMeasurePdf(xmlfile, datfile);
                            if (pdffile != "")
                            {
                                //第五步 插入measuredata 表 pdf
                                int cnt = db.InsertMeasureData(measureId, pdffile, "pdf", true);
                                if (cnt > 0)
                                {
                                    //第六步 插入成功，调用webservice 进行通知
                                }
                                else
                                {
                                    log.Error("DoThingsDiagnos:InsertMeasureData:" + "return cnt <= 0");
                                }
                            }
                            else
                            {
                                log.Error("DoThingsDiagnos:GenMeasurePdf:" + "gen faild xmlfile = " + xmlfile + "datfile = " + datfile);
                            }
                        }
                        else
                        {
                            log.Error("DoThingsDiagnos:ModifyDiagnosXml:" + " faild xmlfile = " + xmlfile + "datfile = " + datfile);
                        }

                    }
                }
            }
            catch (Exception e)
            {
                log.Error("DoThingsDiagnos:" + e.Message);
            }
        }
        private bool ModifyDiagnosXml(string xmlfile,string diagnosresult,string diagnostime)
        {
            xmlfile = rootDir + "/" + xmlfile;
            bool ret = false;
            XmlHelperEx helper = new XmlHelperEx();
            if(helper.LoadXmlFile(xmlfile))
            {
                helper.SetValue("root/ExamInfo/DiagnosisDateTime", diagnostime);
                helper.SetValue("root/ExamInfo/DiagnosticMessage", diagnosresult);
                if(helper.SaveXml(xmlfile))
                {
                    ret = true;
                }
            }
            return ret;
        }
        private void DoThingsMeasure()
        {
            try
            {
                //第一步 根据hospitalId 获取 该医院的所有的测量记录
                DataTable tableMeasure = db.GetMeasureRecord(hospitalId);
                string xmlfile = "";
                string datfile = "";
                for (int i = 0;i<tableMeasure.Rows.Count;i++)
                {
                    DataRow rowMeasureData = tableMeasure.Rows[i];
                    string measureId = rowMeasureData["MeasureId"].ToString();
                    if (rowMeasureData["Type"].ToString() == "dat")
                    {
                        datfile = rowMeasureData["FilePath"].ToString();
                    }
                    if (rowMeasureData["Type"].ToString() == "xml")
                    {
                        xmlfile = rowMeasureData["FilePath"].ToString();
                    }
                    if(rowMeasureData["Type"].ToString() == "pdf")
                    {
                        xmlfile = "";
                        datfile = "";
                    }
                    if (xmlfile != "" && datfile != "")
                    {
                        //第四部 根据dat xml 生成pdf
                        string pdffile = GenMeasurePdf(xmlfile, datfile);
                        if (pdffile != "")
                        {
                            //第五步 插入measuredata 表 pdf
                            int cnt = db.InsertMeasureData(measureId, pdffile, "pdf", true);
                            if (cnt > 0)
                            {
                                //第六步 插入成功，调用webservice 进行通知
                            }
                            else
                            {
                                log.Error("DoThingsMeasure:InsertMeasureData:" + "return cnt <= 0");
                            }
                        }
                        else
                        {
                            log.Error("DoThingsMeasure:GenMeasurePdf:" + "gen faild xmlfile = " + xmlfile + "datfile = " + datfile);
                        }
                    }
                }

            }
            catch(Exception e)
            {
                log.Error("DoThingsMeasure:" + e.Message);
            }
        }
        private string GenMeasurePdf(string xmlfile,string datfile)
        {
            string abxmlfile = rootDir + xmlfile;
            string abdatfile = rootDir + datfile;
            string abfilepath = Path.GetDirectoryName(abxmlfile);
            string abfilename = Path.GetFileNameWithoutExtension(abdatfile);
            
            string refilepath = Path.GetDirectoryName(xmlfile);
            string refilename = Path.GetFileNameWithoutExtension(datfile);

            string pdffile = refilepath + "/" + refilename + ".pdf";

            string openxml = XElement.Load(configDirectory + "AnalyzeOpen.xml").ToString();
            var savereport = XElement.Load(configDirectory + "savereport.xml");

            int ret = ocx.Open(openxml);
            //为报告保存方法的xml参数赋值  xml文件和data文件路径                   
            savereport.Element("ECGFilePath").Element("DATFilePath").Value = abdatfile;
            savereport.Element("ECGFilePath").Element("XMLFilePath").Value = abxmlfile;
            savereport.Element("ReportFormat").Value = "1";

            //报告的文件名
            savereport.Element("FilePath").Value = abfilepath;
            savereport.Element("FileName").Value = abfilename;
            ocx.SaveReport(savereport.ToString());
            ocx.Close();
            return pdffile;
        }
        private bool ReadConfigFile()
        {
            bool ret = false;
            XmlHelperEx xmlHelper = new XmlHelperEx();
            try
            {
                if (xmlHelper.LoadXmlFile(configDirectory + "config.xml"))
                {
                    //加载链接字符串
                    connStr = xmlHelper.GetValue("root/connectionStrings");
                    hospitalId = xmlHelper.GetValue("root/hospitalid");
                    rootDir = xmlHelper.GetValue("root/rootdir");
                    sleepTime = Convert.ToInt32(xmlHelper.GetValue("root/sleeptime"));
                    ret = true;
                }
            }
            catch
            {
                log.Error("LoadXmlFile:" + configDirectory + "config.xml");
            }
            return ret;
        }
    }
}
