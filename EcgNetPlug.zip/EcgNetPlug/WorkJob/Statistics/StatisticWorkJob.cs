﻿using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;

namespace EcgNetPlug.WorkJob.Statistics
{
    public class StatisticWorkJob:BaseJob
    {
        private ILog log = null;
        private string connStr = "";
        private StatisticWorkDb db = null;
        private int sleepTime = 2000;
        public StatisticWorkJob(string name)
        {
            Init(name);
        }
        public override void Init(string name)
        {
            base.Init(name);
            log = LogManager.GetLogger("StatisticWorkJob");
        }
       
        public override bool Start(int sleep = 1000)
        {
            log.Info("Start");
            bool ret = false;
            ret = ReadConfigFile();
            if (!ret)
            {
                log.Error("ReadConfigFile is false and return");
                ReportWorkState(2, 1);
                return false;
            }
            db = new StatisticWorkDb(connStr);

            return base.Start(sleepTime);
        }
        public override bool Stop()
        {
            return base.Stop();
        }
        public override void Run()
        {
            while(running)
            {
                //第一件事 更新所有的区的医疗服务中心数量
                DoThingsUpdateAllMedicalServiceNum();

                //第二件事 更新所有的科室的设备数量
                DoThingUpdateAllMedicalDeviceNum();

                //第三件事 更新所有的统计诊端表
                DoThingUpdateAllDiagnosNum();

                //Thread.Sleep(sleepTime);
                base.Run();
            }
           
        }

        private void DoThingUpdateAllDiagnosNum()
        {
            try
            {
                //throw new NotImplementedException();
                DataTable diagnosTable = db.GetAllDiagnosisNum();
                for (int i = 0; i < diagnosTable.Rows.Count; i++)
                {
                    DataRow diagnosRow = diagnosTable.Rows[i];
                    string medicalId = diagnosRow["MedicalOrgId"].ToString();
                    string departId = diagnosRow["AppliDept"].ToString();
                    string examItemId = diagnosRow["ExamItemId"].ToString();
                    int diagnosCount = Convert.ToInt32(diagnosRow["DiagnosisCount"].ToString());
                    string comeDate = diagnosRow["Date"].ToString();
                    DateTime beginDt = DateTime.Parse(comeDate);
                    string beginYear = beginDt.Year.ToString("00");
                    string beginMonth = beginDt.Month.ToString("00");
                    string beginDay = beginDt.Day.ToString("00");
                    DateTime endDt = beginDt.AddDays(1);
                    string endYear = endDt.Year.ToString("00");
                    string endMonth = endDt.Month.ToString("00");
                    string endDay = endDt.Day.ToString("00");

                    DataTable positiveTable = db.GetAbNormalDiagnosNum(departId, examItemId, beginYear + "-" + beginMonth + "-" + beginDay, endYear + "-" + endMonth + "-" + endDay);
                    int positive = Convert.ToInt32(positiveTable.Rows[0]["Count"].ToString());
                    string positiveRate = (positive * 1.0 / diagnosCount).ToString();
                    int ret = db.UpdateStatisticDiagnosTable(medicalId, departId, examItemId, diagnosCount, beginYear, beginMonth, beginDay, positive, positiveRate);
                    if(ret<=0)
                    {
                        log.Error("UpdateStatisticsDeviceTable:error:" + "medicalId:" + medicalId + " departId:" + departId + " examItemId:" + examItemId + " diagnosCount:" + diagnosCount.ToString());
                        ReportWorkState(2, 1);
                    }
                }
            }
            catch(Exception e)
            {
                log.Error("DoThingUpdateAllDiagnosNum:error:" + e.Message);
                ReportWorkState(2, 1);
            }
            
        }
        private void DoThingUpdateAllMedicalDeviceNum()
        {
            try
            {
                //throw new NotImplementedException();
                DataTable departTable = db.GetAllDepartDevice();
                db.DeleteStatisticDeviceTable();
                for (int i = 0; i < departTable.Rows.Count; i++)
                {
                    DataRow departRow = departTable.Rows[i];
                    string departId = departRow["DepartId"].ToString();
                    string medicalId = departRow["MedicalOrgId"].ToString();
                    string deviceType = departRow["DevType"].ToString();
                    int deviceCount = Convert.ToInt32(departRow["DevCount"].ToString());
                    
                    int ret = db.UpdateStatisticsDeviceTable(departId, medicalId, deviceType, deviceCount);
                    if(ret<=0)
                    {
                        log.Error("UpdateStatisticsDeviceTable:error:" + "departid:" + departId + " medicalid:" + medicalId + " devicetype:" + deviceType + " devicecount:" + deviceCount.ToString());
                        ReportWorkState(2, 1);
                    }
                }
            }
            catch(Exception e)
            {
                log.Error("DoThingUpdateAllMedicalDeviceNum:error:" + e.Message);
                ReportWorkState(2, 1);
            }
           
        }

        private void DoThingsUpdateAllMedicalServiceNum()
        {
            try
            {
                //throw new NotImplementedException();
                //002 表示，我要获取所有的区MedicalId
                DataTable areatable = db.GetAllMedicalId("003");
                for (int i = 0; i < areatable.Rows.Count; i++)
                {
                    DataRow areaRow = areatable.Rows[i];
                    //获取每个区下面的医院ID
                    string areaId = areaRow["MedicalOrgId"].ToString();
                    DataTable hospitalAllTable = db.GetHospitalFromArea(areaId);
                    DataTable hospitalValidTable = db.GetHospitalFromArea(areaId, 1);

                    int hospitalAllCnt = hospitalAllTable.Rows.Count;
                    int departAllCnt = 0;
                    int departValidCnt = 0;
                    int hospitalValidCnt = hospitalValidTable.Rows.Count;
                    for (int j = 0; j < hospitalValidTable.Rows.Count; j++)
                    {
                        //区域下面的每个医院
                        DataRow hospitalRow = hospitalValidTable.Rows[j];
                        string hospitalId = hospitalRow["MedicalOrgId"].ToString();
                        //获取医院下面的所有的科室
                        DataTable departValidTable = db.GetDepartFromHospital(hospitalId, 1);
                        departValidCnt += departValidTable.Rows.Count;
                    }
                    for (int j = 0; j < hospitalAllTable.Rows.Count; j++)
                    {
                        //区域下面的每个医院
                        DataRow hospitalRow = hospitalAllTable.Rows[j];
                        string hospitalId = hospitalRow["MedicalOrgId"].ToString();
                        //获取医院下面的所有的科室
                        DataTable departAllTable = db.GetDepartFromHospital(hospitalId);
                        departAllCnt += departAllTable.Rows.Count;
                    }
                    //更新统计表的医院数量
                    int ret = db.UpdateStatisticBusinessTable(areaId, hospitalAllCnt, hospitalValidCnt, departAllCnt, departValidCnt);
                    if(ret<=0)
                    {
                        log.Error("UpdateStatisticBusinessTable:error:" + "areaId:" + areaId + " hospitalAllCnt:" + hospitalAllCnt + " departAllCnt:" + departAllCnt + " departValidCnt:" + departValidCnt.ToString());
                        ReportWorkState(2, 1);
                    }
                }
            }

            catch (Exception e)
            {
                log.Error("DoThingsUpdateAllMedicalServiceNum:error:" + e.Message);
                ReportWorkState(2, 1);
            }
        }

        private bool ReadConfigFile()
        {
            bool ret = false;
            XmlHelperEx xmlHelper = new XmlHelperEx();
            try
            {
                if (xmlHelper.LoadXmlFile(configDirectory + "config.xml"))
                {
                    //加载链接字符串
                    connStr = xmlHelper.GetValue("root/connectionStrings");
                    sleepTime = Convert.ToInt32(xmlHelper.GetValue("root/sleeptime"));
                    ret = true;
                }
            }
            catch
            {
                
                log.Error("LoadXmlFile:" + configDirectory + "config.xml");
                ReportWorkState(2, 1);
            }
            return ret;
        }
    }
}
